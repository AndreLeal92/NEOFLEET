<?php

require_once __DIR__ . '/../core/Router.php';

$router = new Router();

$router->get('/', function() {
    echo "NeoFleet SaaS ONLINE 🚀";
});

$router->dispatch();